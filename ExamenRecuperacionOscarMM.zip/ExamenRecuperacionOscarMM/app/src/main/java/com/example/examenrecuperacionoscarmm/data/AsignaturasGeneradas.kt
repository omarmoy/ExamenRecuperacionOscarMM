package com.example.examenrecuperacionoscarmm.data

object DataSource {
    val asignaturas = arrayListOf<Asignatura>(
        Asignatura("Historia", 8, 0),
        Asignatura("Lengua", 9, 0),
        Asignatura("Inglés", 12, 0),
        Asignatura("Sociales", 12, 0),
        Asignatura("Biología", 10, 0),
        Asignatura("Física", 9, 0),
        Asignatura("Química", 9, 0),

        )
}