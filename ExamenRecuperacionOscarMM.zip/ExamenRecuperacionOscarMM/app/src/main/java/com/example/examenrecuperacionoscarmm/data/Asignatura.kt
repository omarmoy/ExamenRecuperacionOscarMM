package com.example.examenrecuperacionoscarmm.data

data class Asignatura (val nombre:String, val precioHora:Int, var horas: Int)
